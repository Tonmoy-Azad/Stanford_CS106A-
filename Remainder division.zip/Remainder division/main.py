"""
This is a worked example. This code is starter code; you should edit and run it to 
solve the problem. You can click the blue show solution button on the left to see 
the answer if you get too stuck or want to check your work!
"""

def main():
    num1 = int(input("Please enter an integer to be divided: "))
    num2 = int(input("Please enter an integer to divide by: "))
    division = int(num1/num2)
    division = str(division) 
    remainder = str(num1 % num2)
    print (str("The result of this division is " + division + "with a remainder of " + remainder))



# There is no need to edit code beyond this point

if __name__ == '__main__':
    main()