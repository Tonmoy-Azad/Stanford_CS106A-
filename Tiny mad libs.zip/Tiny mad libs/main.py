"""
This is a worked example. This code is starter code; you should edit and run it to 
solve the problem. You can click the blue show solution button on the left to see 
the answer if you get too stuck or want to check your work!
"""

SENTENCE_START = "Code in Place is fun. I learned to program and used Python to make my " # adjective noun verb


def main():
    adjective = str(input("Please type an adjective and press enter. "))
    noun = str(input(" Please type a noun and press enter. "))
    verb = str(input(" Please type a verb and press enter. "))
    print(str(SENTENCE_START + adjective + " "+ noun + " "+ verb + "!"))


# There is no need to edit code beyond this point

if __name__ == '__main__':
    main()