from karel.stanfordkarel import *

"""
Karel should fill the whole world with beepers.
"""


def main():
    while left_is_clear():
        beeper_row() #fill the row karel is currently in (karel is facing right) with beepers
        get_back() #after finishing, karel gets back to where it started
        move_up() #karel moves on to next row by going up once
    beeper_row() #fencepost problem

def beeper_row():
    while front_is_clear():
        put_beeper()
        move()
    put_beeper()

def get_back():
    turn_around()
    move_forward()

def move_forward():
    while front_is_clear():
        move()

def turn_around():
    for i in range(2):
        turn_left()

def move_up():
    turn_right()
    move()
    turn_right()

def turn_right():
    for i in range(3):
        turn_left()

# There is no need to edit code beyond this point
if __name__ == '__main__':
    main()