from karel.stanfordkarel import *

"""
Karel should fill the whole world with beepers.
"""


def main():
    east_row()   #karel is facing east, so karel makes checkered design and moves along east direction
    west_row()   #karel is facing west, does the same for west direction 

def east_row():
    if facing_east():
        while no_beepers_present(): #as long as there are no beepers in the position karel is standing, karel will continue to put beepers
            put_beeper()            #this is because since karel moves two space, he will always be in a checkered position where he must put beeper
            if front_is_clear():    #if beepers are already placed here, it means karel's job is done.
                move()              # move one space if front is clear 
            else:
                move_up()           # if 1st place is blocked, karel moves up a row
            
            if front_is_clear():
                if no_beepers_present(): #if beepers are present, no need to put beeper again. because job is done
                    move()          #if 2nd place is clear, move
            else:
                if no_beepers_present(): # otherwise go up a row
                    move_up()
                

def west_row():    #same as above
    if facing_west():
        while no_beepers_present():
            put_beeper()
            if front_is_clear():
                move()
            else:
                move_up()
            if front_is_clear():
                if no_beepers_present():
                    move()
            else:
                if no_beepers_present():
                    move_up()

def move_up():
    if facing_east(): #if facing east, and left it blocked,it means karel is at final row, so needs to come start position
        if left_is_blocked():
            turn_right()
            while front_is_clear():
                move()
            turn_right()
            while front_is_clear():
                move()
            turn_left()
            turn_left()
        else:    
            turn_left()  #if facing east, and left isnt blocked, means karel can still move up a row
            move()
            turn_left()
    else: # here else means if facing west
        if right_is_blocked():  #facing west and right is blocked means karel is in final row, so just come to start
            turn_left()
            while front_is_clear():
                move()
            turn_left()
        else:
            turn_right()  #otherwise if facing west and right isnt blocked, karel can still move up a row
            move()
            turn_right()

def turn_right():
    for i in range(3):
        turn_left()





# There is no need to edit code beyond this point
if __name__ == '__main__':
    main()