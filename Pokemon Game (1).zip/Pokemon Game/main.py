from graphics import Canvas
import random

CANVAS_WIDTH = 400
CANVAS_HEIGHT = 400

#variables
global pikachu_hp, charmander_hp
pikachu_hp = 100
charmander_hp = 100
pikachu_attacks = {'Thundershock': 20, 'Tackle': 10}
charmander_attacks = {'Scratch': 10, 'Ember': 20}

def main():
    global canvas
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT)
    game_loop()

def display_health():
    canvas.create_text(30, 200, text="Pikachu HP", font="Arial", font_size= 13)
    canvas.create_text(250, 20, text="Charmander HP", font="Arial", font_size= 13)
    
    #initial health bars
    canvas.create_rectangle(30, 225, 130, 245, color="white", outline="black")
    canvas.create_rectangle(30, 225, 30 + pikachu_hp, 245, color="green", outline="black")
    
    canvas.create_rectangle(250, 50, 350, 70, color="white", outline="black")
    canvas.create_rectangle(250, 50, 250 + charmander_hp, 70, color="green", outline="black")

    # pikachu photo
    canvas.create_image(30, 250, "pikachu.png")
    # charmander photo
    canvas.create_image(270, 80, "charmander.png")

def update_health():
    # update pikachus health
    canvas.create_rectangle(30, 225, 130, 245, color="white", outline="black")
    if pikachu_hp > 0:
        canvas.create_rectangle(30, 225, 30 + pikachu_hp, 245, color="green", outline="black")
    else:
        canvas.create_rectangle(30, 225, 130, 245, color="white", outline="black")

    # update charmanders health
    canvas.create_rectangle(250, 50, 350, 70, color="white", outline="black")
    if charmander_hp > 0:
        canvas.create_rectangle(250, 50, 250 + charmander_hp, 70, color="green", outline="black")
    else:
        canvas.create_rectangle(250, 50, 350, 70, color="white", outline="black")

# main game loop
def game_loop():
    global pikachu_hp, charmander_hp, canvas
    display_health()
    game_over = False

    while not game_over:
        if pikachu_hp <= 0:
            update_health() 
            canvas.create_text(30, 50, text="You Lost!", font="Arial", font_size= 40, color="red")
            game_over = True
            break

        if charmander_hp <= 0:
            update_health() 
            canvas.create_text(30, 50, text="You Won!", font="Arial", font_size = 40, color="green")
            game_over = True
            break

        print("Choose an attack:")
        print("1. Thundershock")
        print("2. Tackle")
        choice = input("Type 1 or 2: ")

        if choice == '1':
            charmander_hp -= 20
            if charmander_hp < 0: charmander_hp = 0  # health cant go negative
            print("Pikachu used Thundershock!")
        elif choice == '2':
            charmander_hp -= 10
            if charmander_hp < 0: charmander_hp = 0  # health cant go negative
            print("Pikachu used Tackle!")
        else:
            print("")
            print("Invalid key. Type either 1 or 2 and then press enter.")
            continue

        update_health()

        # charmander/cpu moves are random
        move = random.choice(list(charmander_attacks.keys()))
        pikachu_hp -= charmander_attacks[move]
        if pikachu_hp < 0: pikachu_hp = 0  # health cant go negative
        print("Charmander used " + str(move) + "!")
        
        update_health()
        print("")

if __name__ == '__main__':
    main()