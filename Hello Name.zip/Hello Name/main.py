def main():
    enter_name = input("What is your name? ")
    print("Hello " + enter_name)

if __name__ == '__main__':
    main()