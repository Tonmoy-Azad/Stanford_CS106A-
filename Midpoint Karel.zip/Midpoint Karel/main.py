from karel.stanfordkarel import *

"""
File: main.py
--------------------
When you finish writing this file, Karel should be able to find
the midpoint
"""

def main(): #THIS CODE WORKS FOR SQUARE WORLDS OF ANY SIZE#
    beepers_everywhere() #put beepers everywhere in the world, then come back to start facing east
    follow_trail() #now follow and collect beepers in spiral, until karel reaches middle point
            
def follow_trail():
    if beepers_present(): #collect beepers as long as beepers are present and move
        while beepers_present():
            pick_beeper()
            if front_is_clear():
                move()
            else: #if front is blocked, turn left to check the column 
                turn_left()
                move()
    if no_beepers_present(): #if there are no beepers, it means karel already collected beeper from here, so in order to move spiral, karel has to go back one step      
        turn_around()
        move()
        turn_right()
        move()
        clear_row() # while loop if beepers are present

def clear_row():
    if beepers_present():  
        while beepers_present():
            pick_beeper()
            if front_is_clear():
                move()
        if front_is_blocked(): 
            turn_around()
            move()
            turn_around()
            turn_left()
            move()
            clear_row()
        if no_beepers_present(): #same as above
            turn_around()
            move()
            turn_right()
            move()
            clear_row()
    else: #if none of the above applies, it means karel has collected all beepers and in now in the centre, but we want karel to be one bottom row
        if facing_south():
            if no_beepers_present():
                move_forward()
                put_beeper()
                turn_left()
        if facing_north():
            if no_beepers_present():
                turn_around()
                move_forward()
                put_beeper()
                turn_left()
        

def beepers_everywhere():
    while no_beepers_present():
        beeper_row()
        get_back()
        move_up()
    
def beeper_row():
    while front_is_clear():
        put_beeper()
        move()
    put_beeper()

def get_back():
    turn_around()
    move_forward()
    turn_around()

def move_up():
    if left_is_clear():
        turn_left()
        move()
        turn_right()
    else:
        turn_right()
        move_forward()
        turn_left()

def move_forward():
    while front_is_clear():
        move()

def turn_around():
    for i in range(2):
        turn_left()

def turn_right():
    for i in range(3):
        turn_left()

if __name__ == '__main__':
    main()