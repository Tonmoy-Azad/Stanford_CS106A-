from karel.stanfordkarel import *

def main():
    move() #move to position 2; where the beepers stock is
    while beepers_present():
        pick_beeper() #pick a beeper 
        if beepers_present(): # checking for multiple beepers, if exist spreading
            while beepers_present() and front_is_clear():
                move() #move with beeper
            put_beeper() #put that picked beeper to new position
            turn_around() #change position of karel to move back to start
            return_to_stock()  #go back to second position
        else: # while no multiple beepers are present, we return to starting position
            put_beeper()
            return_to_base()

def turn_around():
    turn_left()
    turn_left()

def return_to_stock():
    while front_is_clear():  #go back to fisrt position
        move()
    turn_around()
    move()

def return_to_base():
    turn_around()
    move()
    turn_around()
# don't change this code
if __name__ == '__main__':
    main()