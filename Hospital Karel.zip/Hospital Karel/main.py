from karel.stanfordkarel import *

# Here is a place to program your Section problem

def main():
    if front_is_clear():
        while front_is_clear():  
            move_to_beeper()  #karel moves until it steps on the beeper
            build_hospital()   #then karel makes the hospital

def build_hospital(): #make the hospital which is 2 blocks wide and 3 blocks tall
    turn_left()
    move()
    put_beeper()
    move()
    put_beeper()
    turn_right()
    move()
    put_beeper()
    turn_right()
    move()
    put_beeper()
    move()
    put_beeper()
    turn_left()
    if front_is_clear():  #if statement because if front isnt clear, it cant move, such as at the last stage of building hospital
        move()

def turn_right():
    for i in range(3):
        turn_left()

def move_to_beeper():
    while no_beepers_present():
        move()


if __name__ == '__main__':
    main()