"""
This is a worked example. This code is starter code; you should edit and run it to 
solve the problem. You can click the blue show solution button on the left to see 
the answer if you get too stuck or want to check your work!
"""

from karel.stanfordkarel import *

def main():
    for i in range(2):
        move_forward()
        climb_up()
        make_flower()
        climb_down()

def move_forward():
    while front_is_clear():
        move()

def climb_up():
    turn_left()
    while right_is_blocked():
        move()
        
def make_flower():
    put_beeper()
    move()
    turn_right()
    put_beeper()
    move()
    turn_right()
    put_beeper()
    move()
    put_beeper()

def climb_down():
    move_forward()
    turn_left()
    move_forward()

def turn_right():
    for i in range(3):
        turn_left()


# There is no need to edit code beyond this point

if __name__ == '__main__':
    main()