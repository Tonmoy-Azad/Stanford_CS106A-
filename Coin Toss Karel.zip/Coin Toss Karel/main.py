from karel.stanfordkarel import *

def main():
    if random(0.5):
        draw_heads()
    else:
        draw_tails()

def draw_heads():
    move()
    move()
    for i in range(4):
        paint_coin()
        paint_coin_corner()
    go_inside_position()
    draw_face()

def draw_face():
    for i in range(4):
        paint_face()
        paint_face_corner()
    turn_left()
    for i in range(5):
        move()
    paint_corner("black")
    turn_right()
    move()
    move()
    move()
    paint_corner("black")
    turn_right()
    move()
    move()
    turn_left()
    move()
    paint_corner("red")
    turn_right()
    move()
    turn_right()
    move()
    for i in range(4):
        paint_corner("red")
        move()
    turn_right()
    move()
    paint_corner("red")

def paint_face():
    for i in range(4):
        paint_corner("orange")
        move()

def paint_face_corner():
    turn_left()
    move()
    paint_corner("orange")
    turn_right()
    move()
    turn_left()
    move()

def go_inside_position():
    turn_left()
    move()
    move()
    turn_right()
    move()
    move()
    
def paint_coin():
    for i in range(8):
        paint_corner("yellow")
        move()
    
def paint_coin_corner():
    turn_left()
    move()
    paint_corner("yellow")
    turn_right()
    move()
    turn_left()
    move()

def draw_tails():
    move()
    move()
    for i in range(4):
        paint_coin()
        paint_coin_corner()
    turn_left()
    for i in range(5):
        move()
    paint_corner("brown")
    move()
    turn_right()
    move()
    paint_corner("brown")
    move()
    paint_corner("brown")
    move()
    turn_right()
    move()
    paint_corner("brown")
    move()
    turn_left()
    move()
    paint_corner("brown")
    move()
    paint_corner("brown")
    move()
    paint_corner("brown")
    move()
    turn_left()
    move()
    paint_corner("brown")
    move()
    paint_corner("brown")
    move()
    turn_left()
    move()
    paint_corner("brown")
    move()
    paint_corner("brown")
    turn_left()
    move()
    paint_corner("brown")

def turn_right():
    for i in range(3):
        turn_left()

if __name__ == '__main__':
    main()