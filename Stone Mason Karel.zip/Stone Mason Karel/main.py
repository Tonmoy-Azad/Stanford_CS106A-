from karel.stanfordkarel import *

"""
File: main.py
--------------------
When you finish writing this file, Karel should have repaired 
each of the columns in the temple
"""

def main():
    while front_is_clear():
        make_column() #make the first column
        get_back() #get back to where karel started, facing right
        make_gap()  #gap until next column
    make_column() #fencepost problem
    get_back() #karel hast to be at bottom, facing right

def make_column(): #put beepers on a column
    put_beeper()
    turn_left()
    while front_is_clear():
        move()
        put_beeper()

def get_back():
    turn_around()
    move_forward()
    turn_left()

def move_forward():
    while front_is_clear():
        move()

def turn_right():
    for i in range(3):
        turn_left()

def turn_around():
    for i in range(2):
        turn_left()

def make_gap():
    for i in range(4):
        move()

if __name__ == '__main__':
    main()