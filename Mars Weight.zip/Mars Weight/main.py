"""
Prompts the user for a weight on Earth
and prints the equivalent weight on Mars.
"""
constant = 0.378
def main():
    weight_on_earth = int(input("Enter a weight on Earth: "))
    weight_on_mars = weight_on_earth * constant
    rounded_weight_on_mars = str(round (weight_on_mars, 2))
    print(str("The equivalent weight on Mars: "+ rounded_weight_on_mars))

if __name__ == "__main__":
    main()