"""
This is a worked example. This code is starter code; you should edit and run it to 
solve the problem. You can click the blue show solution button on the left to see 
the answer if you get too stuck or want to check your work!
"""

from karel.stanfordkarel import *

def main():
    while front_is_clear():  #as long as front is clear, karel will make a crosswalk
        full_crosswalk()
        if front_is_clear(): #if front is blocked, we dont need to make gap
            make_gap()
    
def make_gap():
    for i in range(4): #3 spaces of gap
        move()

def full_crosswalk():  #full crosswalk means 2 columns of beeper
    while front_is_clear():
        half_crosswalk()   #half crosswalk means 1 column of beeper
    if front_is_blocked():  #here front_is_blocked means north is blocked. so karel has to turn right and continue
        turn_right()
        move()
        turn_around()
        half_crosswalk()   #this is other half of the crosswalk
        turn_left()

def half_crosswalk():
    turn_left()          #karel has to look north
    while front_is_clear():
        put_beeper()
        move()
    put_beeper() #fencepost problem

def turn_right():
    for i in range(3):
        turn_left()

def turn_around():
    for i in range(2):
        turn_left()


# There is no need to edit code beyond this point

if __name__ == '__main__':
    main()