# Each year for a human is like 7.18 years for a dog
DOG_YRS_MULTIPLIER = 7.18  

def main():
    num1 = int(input("Enter an age in calendar years: "))
    result = str(num1 * DOG_YRS_MULTIPLIER)
    print(str("That's "+ result + " in dog years!"))

# There is no need to edit code beyond this point
if __name__ == '__main__':
    main()