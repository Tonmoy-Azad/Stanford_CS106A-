from karel.stanfordkarel import *

# File: warmup.py
# -----------------------------
# The warmup program defines a "main"
# function which currently just has one
# Command. Add two more commands to make karel: move(),
# pick_beeper(), move()
def main():
    move()
    pick_beeper()
    move()
   
   
   

# don't edit these next two lines
# they tell python to run your main function
if __name__ == '__main__':
    main()