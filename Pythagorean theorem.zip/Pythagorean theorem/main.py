"""
This is a worked example. This code is starter code; you should edit and run it to 
solve the problem. You can click the blue show solution button on the left to see 
the answer if you get too stuck or want to check your work!
"""

import math

def main():
    length_AB = (int(input("Enter the length of AB: ")))
    length_AC = (int(input("Enter the length of AC: ")))
    squared_AB = length_AB ** 2
    squared_AC = length_AC ** 2
    squared_BC = squared_AB + squared_AC 
    hypotenuse_BC = str(math. sqrt(squared_BC))
    print("The length of BC (the hypotenuse) is: " + hypotenuse_BC)


# There is no need to edit code beyond this point

if __name__ == '__main__':
    main()