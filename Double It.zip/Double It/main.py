def main():
    
    curr_value = int(input("Enter a number: "))
    while curr_value < 100 :
        curr_value = curr_value*2 
        print (str(curr_value))
        
    

if __name__ == '__main__':
    main()