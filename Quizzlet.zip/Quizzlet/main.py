def main():
    translations = {
        "hello": "hola",
        "dog": "perro",
        "cat": "gato",
        "well": "bien",
        "us": "nos",
        "nothing": "nada",
        "house": "casa",
        "time": "tiempo"
    }

    score = 0
    for key in translations:
        value = translations[key]
        user = input("What is the Spanish translation for " + str(key) + "? ")
        if user == value:
            print ("That is correct!")
            score = score + 1
        else:
            print ("That is incorrect, the Spanish translation for " + str(key) + " is " + str(value) + ".")
        print ("")
    print ("You got " + str(score)+ "/8 words correct, come study again soon!")

if __name__ == '__main__':
    main()