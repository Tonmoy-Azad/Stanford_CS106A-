"""
This is a worked example. This code is starter code; you should edit and run it to 
solve the problem. You can click the blue show solution button on the left to see 
the answer if you get too stuck or want to check your work!
"""

from karel.stanfordkarel import *

def main():
    while front_is_clear():
        place_beeper()
    place_beeper()
    
def place_beeper():
    turn_right()
    while front_is_clear():
        move()
    put_beeper()
    turn_up()
    while front_is_clear():
        move()
    turn_right()
    if front_is_clear():
        move()
    
def turn_right():
    for i in range(3):
        turn_left()
def turn_up():
    for i in range(2):
        turn_left()


# There is no need to edit code beyond this point

if __name__ == '__main__':
    main()