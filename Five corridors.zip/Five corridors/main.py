from karel.stanfordkarel import *

def main():
    for i in range(4):
        check_corridor()
    last_corridor()
    
def turn_back():
    turn_left()
    turn_left()

def turn_right():
    for i in range(3):
        turn_left()

def check_corridor(): 
    while front_is_clear():
        move()
    if no_beepers_present():
        put_beeper()
    turn_back()
    while front_is_clear():
        move()
    turn_right()
    move()
    turn_right()

def last_corridor():
    while front_is_clear():
        move()
    if no_beepers_present():
        put_beeper()
    turn_back()
    while front_is_clear():
        move()
    turn_back()






# There is no need to edit code beyond this point

if __name__ == '__main__':
    main()
