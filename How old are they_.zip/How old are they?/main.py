"""
This is a worked example. This code is starter code; you should edit and run it to 
solve the problem. You can click the blue show solution button on the left to see 
the answer if you get too stuck or want to check your work!
"""

def main():
    Anton = 21
    Beth = Anton + 6
    Chen = Beth + 20
    Drew = Chen + Anton
    Ethan = Chen
    print("Anton is " + str(Anton) +
    "\n Beth is " + str(Beth) +
    "\n Chen is " + str(Chen) +
    "\n Drew is " + str(Drew) +
    "\n Ethan is " + str(Ethan))


# There is no need to edit code beyond this point

if __name__ == '__main__':
    main()