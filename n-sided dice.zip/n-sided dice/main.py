import random

def main():
    num_of_sides = int(input("How many sides does your dice have? "))
    roll = str(random.randint(1, num_of_sides))
    print(str("Your roll is "+ roll))



if __name__ == '__main__':
    main()