"""
This is a worked example. This code is starter code; you should edit and run it to 
solve the problem. You can click the blue show solution button on the left to see 
the answer if you get too stuck or want to check your work!
"""

def main():
    square_number = input("Type a number to see its square: ")
    square_number = float(square_number)
    product = square_number * square_number
    print(str(square_number) + " squared is " + str(product))


# There is no need to edit code beyond this point

if __name__ == '__main__':
    main()