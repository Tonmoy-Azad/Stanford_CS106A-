from karel.stanfordkarel import *

"""
Each row starts with a stack of beepers. Karel should pick them
up, one at a time, and spread them down the row. 
Caution! Karel can't count, and starts with infinite beepers in
her bag. How can you solve this puzzle?
"""


def main():
    move() #move to 2nd place, where beeper stack is present
    spread_beeper() 

def spread_beeper():
    while beepers_present(): #as long as there are beepers in the 2nd place, karel picks up beeper
        if beepers_present(): 
            pick_beeper()
            if beepers_present(): #if function because Karel shouldnt pick up all the beeper. rather keep the last one 
                move()
                if no_beepers_present(): #if no beepers, then Karel puts one beeper and gets back to 2nd place
                    put_beeper()
                    get_back()
                    move()
                else:
                    while beepers_present(): #if beeper is present, it means karel already placed beeper once before. So karel hast to move to a place where there are no beeper
                        move()
                    put_beeper()
                    get_back() #karel gets back to 2nd place again
                    move()
                    spread_beeper() #the loopp continues until the last beeper
            belse:
                put_beeper() #once karel picks last beeper, there will be no beeper present in 2nd place. So karel has to put one down and move to 1st place (job)
                get_back()
                    
def get_back():
    turn_around()
    move_forward()
    turn_around()

def turn_around():
    for i in range(2):
        turn_left()

def move_forward():
    while front_is_clear():
        move()



    

# There is no need to edit code beyond this point
if __name__ == '__main__':
    main()