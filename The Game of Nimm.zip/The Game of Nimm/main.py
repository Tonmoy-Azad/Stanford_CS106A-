def main():
    stones = 20 
    player = 1
    

    while stones>0:
        print("There are " + str(stones) + " stones left.")
        remove = int(input("Player " + str(player) + " would you like to remove 1 or 2 stones? "))
        while remove != 1 and remove !=2:
            remove = int(input("Please enter 1 or 2: "))
        if player == 1:
            player = 2
        else:
            player = 1
        stones = stones - remove
        print("")
        if stones<= 0 and player == 1:
            print("Player 1 wins!")

        if stones<= 0 and player == 2:
            print("Player 2 wins!")
    
        



if __name__ == '__main__':
    main()